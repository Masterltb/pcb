FV-CTRL RevB — NATIVE KICAD REVIEW ONLY

Chưa phát hành sản xuất; không có Gerber/drill trong gói này.
Đọc docs/revb/RevB-status.md trước. Nguồn thiết kế đã kiểm tra: commit a7dd57b.

Giải nén nguyên cấu trúc. Mở hardware/revb/FV-CTRL_RevB.kicad_pro bằng KiCad 10.
Không tách hardware/ khỏi libs/. Thư viện chuẩn KiCad 10 cần thiết khi chỉnh sửa.
Schematic gồm trang gốc và 9 trang chức năng. PNG/SVG ở docs/ để xem trước.

Mục 9 AGENTS.md yêu cầu duyệt rủi ro trước Gerber. DRC/ERC sạch không thay cho
DFM xưởng, tuning RF, kiểm tra nhiệt hoặc phép thử servo trên mẫu thật.
Đọc cả bản vẽ lắp ráp mặt trước và mặt sau. Ảnh 3D thiếu một số model, gồm U1;
không dùng ảnh 3D để duyệt cơ khí. RevB chưa được kiểm chứng import EasyEDA.

BOM/CPL chỉ để review/báo giá; tồn kho, thay thế, rotation và stencil cần xưởng duyệt.
File SMT dùng gốc phụ góc trái dưới; bản đồ EP dùng tọa độ PCB tuyệt đối.
USB DATA ONLY: cấp 12 V chính khi nạp, USB không cấp nguồn cho board.

reports/ chứa báo cáo kiểm tra và netlist. Có thể chạy lại hai verifier bằng
Python đi kèm KiCad có pcbnew sau khi xuất netlist dạng kicadxml.
SHA256SUMS.txt kiểm tra tính toàn vẹn từng file trong gói.
