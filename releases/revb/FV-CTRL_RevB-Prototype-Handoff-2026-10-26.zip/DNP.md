# Do not populate — RevB prototype

Optional limit switch connectors and their pull-up/filter components.
Do not install unless a revised assembly instruction is approved.

| Reference | Value |
|---|---|
| J13 | LS1 DNP |
| R16 | 10k |
| C7 | 100nF |
| J14 | LS2 DNP |
| R17 | 10k |
| C8 | 100nF |
| J15 | LS3 DNP |
| R18 | 10k |
| C9 | 100nF |
| J16 | LS4 DNP |
| R19 | 10k |
| C10 | 100nF |
