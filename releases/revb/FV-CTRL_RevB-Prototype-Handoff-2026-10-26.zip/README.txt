FV-CTRL RevB — PROTOTYPE / QUOTATION HANDOFF — 2026-10-26

Start with FABRICATION_NOTES.md. This package includes actual Gerber and drill
files exported from the existing RECOM-powered RevB layout. No design changes.
It is for DFM review, quotation and prototype preparation, not production qualification.

For a bare PCB quote, upload fabrication/FV-CTRL_RevB-Gerber-2026-10-26.zip.
For PCBA, also provide bom/, assembly/ and DNP.md. BOM/CPL column mapping and
orientation must be checked with the assembler. 63 SMT references, 151 total BOM refs.
Quantity, finish, purchasing, THT assembly, panel/tooling and test scope are to be quoted.

Before manufacture, agree on QFN/0201 assembly, the 25 EP holes in the map,
via treatment and stencil with the factory. Do not fill THT holes or all 0.2 mm holes.
Two external XL4015 converters and real-machine test loads are separate scope.
USB is DATA ONLY; use main 12 V power for programming. Limits are DNP by default.

preview/ is rendered from the actual Gerbers (bottom shown as viewed from bottom).
Coordinates in factory Gerber/drill files are NOT mirrored. See the notes for CPL origin.
verification/ holds current export checks and drill maps. A Gerber parser/render check
was performed; KiCad GerbView GUI review was not run in this session.

No real-board qualification or firmware for factory functional acceptance is supplied.
The included bring-up checklist is an engineering reference, not a complete factory test specification.
SHA256SUMS.txt checks every other file in this package.
